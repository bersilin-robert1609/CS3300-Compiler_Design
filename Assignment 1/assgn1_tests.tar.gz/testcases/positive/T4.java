#defineExpr NUM(a,b,c) ((a+c)+b)

class T4 {
    public static void main(String[] a){
      System.out.println (NUM(1,2,3));
    }
}
