#defineStmt2 NUM(a,b) {
  System.out.println(a);
  System.out.println(b);
}

class T7 {
    public static void main(String[] a){
      System.out.println (0);
    }
}

class Foo {
  public int foo () {
    NUM(5,10);
    return 0;
  }
}
