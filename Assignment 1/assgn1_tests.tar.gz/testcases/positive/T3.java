#defineExpr2 NUM(a,b) (a+b)

class T3 {
    public static void main(String[] a){
      System.out.println (NUM(1,2));
    }
}
