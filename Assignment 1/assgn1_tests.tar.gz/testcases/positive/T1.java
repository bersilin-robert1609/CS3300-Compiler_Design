#defineExpr0 NUM() (10+a)

class T1 {
    public static void main(String[] a){
      System.out.println (0);
    }
}

class Foo {
  public int foo (int a) {
      System.out.println (NUM());
  }
}
