#defineExpr1 NUM(a) (10+a)

class T2 {
    public static void main(String[] a){
      System.out.println (NUM(5));
    }
}
