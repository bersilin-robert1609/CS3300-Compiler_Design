#defineStmt0 NUM() {System.out.println(0);}

class T5 {
    public static void main(String[] a){
      System.out.println (0);
    }
}

class Foo {
  public int foo () {
    NUM();
    return 0;
  }
}
