#defineStmt1 NUM(a) { }

class T6 {
    public static void main(String[] a){
      System.out.println (0);
    }
}

class Foo {
  public int foo () {
    NUM(0);
    return 0;
  }
}
