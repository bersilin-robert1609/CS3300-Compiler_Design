class SimpleMain {
    public static void main(String[] a){
        System.out.println(3310);
    }
} 
