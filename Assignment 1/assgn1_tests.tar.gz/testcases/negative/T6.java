#defineStmt NUM(a) { } //Error: defineStmt must have atleast 3 arguments

class T6 {
    public static void main(String[] a){
      System.out.println (0);
    }
}
