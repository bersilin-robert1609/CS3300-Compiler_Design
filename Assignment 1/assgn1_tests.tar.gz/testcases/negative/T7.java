#defineStmt2 NUM(a) {} //Error: defineStmt2 must have atleast 2 arguments

class T7 {
    public static void main(String[] a){
      System.out.println (0);
    }
}
