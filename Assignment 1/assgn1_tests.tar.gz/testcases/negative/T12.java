class T1 {
  public static void main (String[] a) {
    System.out.println(0+1+2);
  }
}
