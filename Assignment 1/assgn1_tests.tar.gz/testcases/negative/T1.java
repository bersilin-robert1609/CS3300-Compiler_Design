#defineExpr0 NUM(a) (10+a) // Error: defineExpr0 must have 0 arguments

class T1 {
    public static void main(String[] a){
      System.out.println (0);
    }
}
