class T1 {
  public static void main (String[] a) {
    System.out.println(0);
    System.out.println(0);
  }
}
