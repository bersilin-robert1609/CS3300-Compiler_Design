#defineStmt0 NUM(a) { } //Error: defineStmt0 must have 0 arguments

class T5 {
    public static void main(String[] a){
      System.out.println (0);
    }
}
