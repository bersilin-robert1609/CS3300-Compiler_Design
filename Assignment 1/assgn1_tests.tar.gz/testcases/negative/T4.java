#defineExpr2 NUM(a) (10+a) //Error: defineExpr2 must have exactly 2 arguments

class T4 {
    public static void main(String[] a){
      System.out.println (0);
    }
}
