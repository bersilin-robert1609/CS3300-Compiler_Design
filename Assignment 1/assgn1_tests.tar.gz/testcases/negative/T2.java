#defineExpr NUM(a) (10+a) //Error: defineExpr must have atleast 3 arguments

class T2 {
    public static void main(String[] a){
      System.out.println (0);
    }
}
