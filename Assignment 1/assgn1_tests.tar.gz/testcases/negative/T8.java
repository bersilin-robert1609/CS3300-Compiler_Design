class T1 {
}
//Error: MainClass is missing
