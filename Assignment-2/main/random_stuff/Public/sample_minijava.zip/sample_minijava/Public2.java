// Type mismatch

class Add {
    public static void main(String[] a) {
        System.out.println(1336 + false);
    }
}