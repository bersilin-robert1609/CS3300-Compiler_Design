class SimpleTest2{
    public static void main(String[] a){
        System.out.println(1);
    }
}

class A
{ int x; }

class B extends A
{ 
  boolean x; 
  public int oomb()
  {return x;}
}